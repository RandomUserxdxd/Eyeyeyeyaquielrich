_G.Version = "2.0.0"
_G.Discord = "https://discord.gg/tmrx"
