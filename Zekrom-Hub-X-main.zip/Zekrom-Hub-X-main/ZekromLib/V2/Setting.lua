_G.Discord = "https://discord.gg/tmrx"
